package com.shengsheng.checkon.entity;

import java.util.List;

public class Model {

	private List<Device> items;

	public List<Device> getItems() {
		return items;
	}

	public void setItems(List<Device> items) {
		this.items = items;
	}
	
	
}
