package com.shengsheng.checkon.entity;

import java.time.Instant;

/**
 * 
 * @author LiPeiTong
 * 2019年3月19日 上午8:58:12
 * <tr>设备实体类</tr>
 * 	<td></td>
 */
public class Device {
	
	private String name;//设备名
	private String mac;//mac地址
    /**
     * @return the name
     */
    public String getName() {
        return name;
    }
    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }
    /**
     * @return the mac
     */
    public String getMac() {
        return mac;
    }
    /**
     * @param mac the mac to set
     */
    public void setMac(String mac) {
        this.mac = mac;
    }
    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "Device [name=" + name + ", mac=" + mac + "]";
    }
	
}
