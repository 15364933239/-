package com.shengsheng.service;


import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.shengsheng.checkon.entity.Device;
import com.shengsheng.checkon.entity.Model;
import com.shengsheng.web.util.MyTaskAnnotation;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

@Controller
@RequestMapping("/interface")
public class DeviceService {

	@RequestMapping("/Demo")
	@ResponseBody
	public JSONObject transmit() {
		System.out.println(123);
		List<Device> list = MyTaskAnnotation.transmit();
		Model json = new Model();
		json.setItems(list);
		JSONObject obj = JSONObject.fromObject(json);
		return obj;
	}
}
