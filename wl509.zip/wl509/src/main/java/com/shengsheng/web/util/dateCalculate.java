package com.shengsheng.web.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.Period;
import java.util.Date;

import org.junit.Test;

public class dateCalculate {
	
	@Test
	public void test() throws ParseException {
//		LocalDate today = LocalDate.now();
//		System.out.println(today);
//		LocalDate today1 = LocalDate.of(2019, 3, 10);
//		System.out.println(today1);
//		
//		Period p = Period.between(today1, today);
//		System.out.println(p.getYears()+p.getMonths()+p.getDays());
		
//		Instant inst1 = Instant.now(); //当前的时间 
//		System.out.println("Inst1：" + inst1); 
//		Instant inst2 = inst1.plus(Duration.ofSeconds(10)); //当前时间+10秒后的时间 
//		System.out.println("Inst2：" + inst2); 
//		Instant inst3 = inst1.plus(Duration.ofDays(125)); //当前时间+125天后的时间 
//		System.out.println("inst3：" + inst3); 
//		System.out.println("以毫秒计的时间差：" + Duration.between(inst1, inst2).toMillis()); 
//		System.out.println((Duration.between(inst1, inst3).getSeconds())/3600);
//		
//		SimpleDateFormat df = new SimpleDateFormat("y-M-d H:m:s");//设置日期格式
//		String format = df.format(new Date());
//		Date date2 = df.parse(format);
//		
//		Instant instant = date2.toInstant();
//		System.out.println(instant);
		
		Date now = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String dateString = formatter.format(now);
		
		System.out.println(dateString);
		
	}

}
