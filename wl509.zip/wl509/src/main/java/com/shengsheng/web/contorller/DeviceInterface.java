package com.shengsheng.web.contorller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;
import org.xml.sax.SAXException;

import com.shengsheng.checkon.entity.Device;
import com.shengsheng.web.util.MyTest2;
import com.shengsheng.web.util.RestTemplateUtil;

import net.sf.json.JSONArray;

/**
 * 
 * @author LiPeiTong
 * 2019年3月18日 下午5:53:41
 * <tr>测试传输集合数据</tr>
 * 	<td></td>
 */
public class DeviceInterface{
	
	/*public static void main(String[] args) throws InterruptedException, IOException, SAXException, ServletException{
        
		SimpleDateFormat df = new SimpleDateFormat("y-M-d H:m:s");//设置日期格式
        
		List<Device> devicelists = MyTest2.getOnLineDevices("123456");
		for (Device device : devicelists) {
			device.setTime(df.format(new Date()));
		}
		JSONArray json = JSONArray.fromObject(devicelists);
		System.out.println(json);
		Test.sendInf(json);
		HttpHeaders headers = new HttpHeaders();
		HttpEntity<JSONArray> entity = new HttpEntity<JSONArray>(json,headers);
		System.out.println(entity);
		RestTemplate restTemplate = RestTemplateUtil.getInstance("utf-8");
		String url = "http://localhost:9999/clsMnger/interfaceTest/Demo";
		ResponseEntity<String> result = restTemplate.exchange(url, HttpMethod.POST, entity, String.class);
		System.out.println(result);
//		Test.sendInf(json);
		
		
	}*/

}
